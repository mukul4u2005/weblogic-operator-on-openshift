"""
Copyright (c) 2017, 2019, Oracle Corporation and/or its affiliates.  All rights reserved.
Licensed under the Universal Permissive License v 1.0 as shown at https://oss.oracle.com/licenses/upl.

This package provides the WLST knowledge base used by the rest of the code to understand how to perform
their work across WebLogic versions and WLST modes.
"""
